var a = 20;
var b = 30;
var resultat_ = ( a + b);
alert(resultat_);

var math = 8;
var français = 15
var hg = 17 
var moyenne = (math + français + hg) / 3;
alert( 'la moyenne est de ' + moyenne) ;

var budget = prompt ( "entrer votre budget" )
var achat_ = 85
if (budget >= Number(achat_)){
    alert(  " vous avez  assez de budget"); }
else {
    alert (   " vous n'avez  assez de budget"); }



